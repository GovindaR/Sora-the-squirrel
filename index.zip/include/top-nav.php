<button onclick="topFunction()" id="myBtn" title="Go to top" class="off"><i class="fas fa-angle-up"></i></button>
<section class="top-nav">
        <div class="container">
            <div class="row">
                    <nav class="nav">
                            <input type="checkbox" class="navigation__checkbox" id="navi-toggle">
        
                            <label for="navi-toggle" class="navigation__button">
                                <span class="navigation__icon">&nbsp;</span>
                            </label>
                            <div class="navigation__background">&nbsp;</div>
        
                            <nav class="navigation__nav">
                                <ul id="nav">
                                    <li class="active1">
                                    <a href="#Home" onclick="window.location='/demo';">Home</a>
                                    </li>
                                    <li>
                                        <a href="#Feature">Features</a>
                                    </li>
                                    <li>
                                        <a href="#Download">Download</a>
                                    </li>
                                    <li>
                                        <a href="#Testimonials">Testimonials</a>
                                    </li>
                                    <li>
                                        <a href="#Contact-Us">Contact Us</a>
                                    </li>
                                </ul>
                            </nav>
                        <a class="logo" href="/demo">
                            <img src="img/logo.png" alt="logo">
                        </a>
                    </nav>
            </div>
        </div>
    </section>