<footer>
       <div class="container">
           <div class="row ">
               <div class="social clearfix center">
                <div class="col-md-4">
                   <div class="policy__term">
                        <a href="/demo/policy">Privacy Policy</a>
                        <a href="/demo/terms">Terms & Conditions</a>
                   </div>
                </div>
                <div class="col-md-4">
                  <div class="icons">
                        <i class="fab fa-facebook-f"></i>
                        <i class="fab fa-pinterest-p"></i>
                        <i class="fab fa-youtube"></i>
                        <i class="fab fa-twitter"></i>
                   </div>
                </div>
                   <div class="col-md-4">
                     <p class="margin center">Copyright &COPY; 2018,Sora the Squirrel.All rights reserved</p>
                   </div>
                   
               </div>
           </div>
       </div>
   </footer>